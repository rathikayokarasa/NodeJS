var http = require('http');
var ex1 = require('./sumavg.js');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(`Sum Number =  ${ex1.sumNum(123, 321)}` );
    res.write(`Average Number = ${ex1.average(123, 321)}` );
    res.end();
}).listen(8000);
